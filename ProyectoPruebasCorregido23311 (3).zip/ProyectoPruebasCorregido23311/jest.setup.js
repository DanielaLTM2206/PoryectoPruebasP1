// jest.setup.js
require("jest-fetch-mock").enableMocks(); 